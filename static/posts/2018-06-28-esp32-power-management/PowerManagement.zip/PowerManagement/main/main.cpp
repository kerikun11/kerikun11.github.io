#include <stdio.h>
#include "esp_err.h"
#include "esp_log.h"
#include "esp_pm.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/rtc_io.h"

// Make sure we have C-declarations in C++ programs
extern "C" {
#include "esp_clk.h"
};

#define TAG "main"

esp_pm_lock_handle_t out_handle_cpu;
esp_pm_lock_handle_t out_handle_apb;
esp_pm_lock_handle_t out_handle_light;
auto pin_led = GPIO_NUM_27;

void printInfo() {
  ESP_LOGI(TAG, "the list of all locks:");
  ESP_ERROR_CHECK(esp_pm_dump_locks(stdout));
  printf("\n");
  ESP_LOGI(TAG, "CPU Frequency: %d [MHz]", esp_clk_cpu_freq() / 1000000);
  ESP_LOGI(TAG, "APB Frequency: %d [MHz]", esp_clk_apb_freq() / 1000000);

  ESP_LOGI(TAG, "Start wait...");
  vTaskDelay(2000 / portTICK_PERIOD_MS);
  ESP_LOGI(TAG, "End wait");
}

void lock(esp_pm_lock_handle_t out_handle) {
  ESP_ERROR_CHECK(esp_pm_lock_acquire(out_handle));
  printInfo();
  ESP_ERROR_CHECK(esp_pm_lock_release(out_handle));
  printInfo();
}

void pm_init() {
  esp_pm_config_esp32_t esp_pm_config_esp32;
  esp_pm_config_esp32.max_cpu_freq = RTC_CPU_FREQ_240M;
  esp_pm_config_esp32.min_cpu_freq = RTC_CPU_FREQ_XTAL;
  esp_pm_config_esp32.light_sleep_enable = true;
  ESP_ERROR_CHECK(esp_pm_configure(&esp_pm_config_esp32));
}

void pm_lock_init() {
  ESP_ERROR_CHECK(
      esp_pm_lock_create(ESP_PM_CPU_FREQ_MAX, 0, "cpu", &out_handle_cpu));
  ESP_ERROR_CHECK(
      esp_pm_lock_create(ESP_PM_APB_FREQ_MAX, 0, "apb", &out_handle_apb));
  ESP_ERROR_CHECK(
      esp_pm_lock_create(ESP_PM_NO_LIGHT_SLEEP, 0, "light", &out_handle_light));
}

void led_task(void *arg) {
  while (1) {
    ESP_ERROR_CHECK(rtc_gpio_set_level(pin_led, 1));
    ESP_ERROR_CHECK(rtc_gpio_hold_en(pin_led));
    vTaskDelay(500 / portTICK_PERIOD_MS);
    ESP_ERROR_CHECK(rtc_gpio_hold_dis(pin_led));

    ESP_ERROR_CHECK(rtc_gpio_set_level(pin_led, 0));
    ESP_ERROR_CHECK(rtc_gpio_hold_en(pin_led));
    vTaskDelay(500 / portTICK_PERIOD_MS);
    ESP_ERROR_CHECK(rtc_gpio_hold_dis(pin_led));
  }
}

extern "C" void app_main() {
  ESP_LOGI(TAG, "Hello, world!");
  // pm init
  pm_init();
  // pm lock init
  pm_lock_init();
  // led init
  ESP_ERROR_CHECK(rtc_gpio_init(pin_led));
  ESP_ERROR_CHECK(rtc_gpio_set_direction(pin_led, RTC_GPIO_MODE_OUTPUT_ONLY));
  ESP_ERROR_CHECK(rtc_gpio_set_level(pin_led, 1));

  xTaskCreatePinnedToCore(led_task, "led", 8192, NULL, 0, NULL, tskNO_AFFINITY);

  lock(out_handle_cpu);
  lock(out_handle_apb);
  lock(out_handle_light);

  while (1) {
    vTaskDelay(portMAX_DELAY);
  }
}

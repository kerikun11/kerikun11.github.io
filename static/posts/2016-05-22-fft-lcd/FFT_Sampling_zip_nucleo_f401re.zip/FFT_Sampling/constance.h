#ifndef CONSTANCE_H
#define CONSTANCE_H

#include "mbed.h"

extern const uint8_t me[30][400];
extern const uint8_t keri[30][400];
extern uint8_t screen[30][400];
extern const uint8_t pattern[][5];
 
uint8_t encode(uint8_t asciicode);
uint8_t character(char ascii, uint8_t line);

#endif
//--------------------------------------------------------------
// Sampling and Spectrum analysis using FFT
// Copyright (c) 2014 MIKAMI, Naoki,  2014/06/29
//--------------------------------------------------------------

#include "mbed.h"
#include "AdcInternal.hpp"
#include "fftReal.hpp"
#include "constance.h"

using namespace Mikami;

// sampling frequency
const float FS_ = 10.0e3f;
const int N_FFT_ = 1024;

Adc adc_(A0);
Ticker timer_;      // for timer interrupt
DigitalIn userButton_(USER_BUTTON);
FftReal fft_(N_FFT_);

float xn_[N_FFT_+1];
volatile int count_;

// Sampling
void TimerIsr()
{
    xn_[count_] = adc_.Read();  // AD
    count_++;
}

DigitalOut CLK(PA_10);
DigitalOut DAT(PB_3);
DigitalOut SCS(PB_5);
DigitalOut COM(PB_4);
DigitalOut VCC(PB_10);
DigitalOut GND(PA_8);

void TFT_send(uint8_t mode, uint8_t line)
{
    uint16_t i;

    SCS = 0;
    CLK = 0;
    DAT = 0;
    //wait_us(10);

    // Start!
    SCS = 1;
    //wait_us(10);

    // Mode Select
    for (i = 0; i < 8; i++) {
        CLK = 0;
        DAT = (mode >> i)%2;
        //wait_us(1);
        CLK = 1;
        //wait_us(1);
    }
    // Line Select
    for (i = 0; i < 8; i++) {
        CLK = 0;
        DAT = ((line + 1) >> i)%2;
        //wait_us(1);
        CLK = 1;
        //wait_us(1);
    }
    // Data Send
    uint8_t data_p = line / 8;
    uint8_t data_s = line % 8;
    for (i = 0; i < 400; i++) {
        CLK = 0;
        DAT = (~(screen[data_p][i] >> data_s))%2;
        ////wait_us(1);
        CLK = 1;
        //wait_us(1);
    }
    // Dumy Data
    for (i = 0; i < 16; i++) {
        CLK = 0;
        DAT = 0;
        //wait_us(1);
        CLK = 1;
        //wait_us(1);
    }
    CLK = 0;
    DAT = 0;
    //wait_us(10);
    SCS = 0;
}

void printlcd(void)
{
    for (uint8_t line = 0; line < 240/4; line++) {
        TFT_send(1, line*4+0);
        TFT_send(1, line*4+1);
        TFT_send(1, line*4+2);
        TFT_send(1, line*4+3);
    }
}

int main()
{
    while(true) {
        printf("Ready.\r\n");
        //while(userButton_);     // wait for user button pressed
        printf("User button is pushed!\r\n");

        count_ = 0;
        timer_.attach_us(&TimerIsr, 1.0e6f/FS_);
        printf("Waiting...\r\n");
        while (count_ < N_FFT_+1);
        timer_.detach();        // Detach TimerIsr
        printf("End of Sampling.\r\n");

        float xnW[N_FFT_];      // for windowed data
        Complex yk[N_FFT_/2+1];
        float yDb[N_FFT_/2+1];

        // Windowing
        float pi2N = 6.283185f/N_FFT_;
        for (int n=0; n<N_FFT_; n++)
            xnW[n] = (xn_[n+1] - xn_[n])*(0.54f - 0.46f*cosf(pi2N*n));

        // Execute FFT
        fft_.Execute(xnW, yk);

        // Square of absolute value of FFT
        for (int n=0; n<=N_FFT_/2; n++)
            yDb[n] = norm(yk[n]);

        // Get maximum value of yk[n]
        float max = 0;
        for (int n=0; n<=N_FFT_/2; n++)
            max = (yDb[n] > max) ? yDb[n] : max;

        // Normalized spectra to dB
        for (int n=0; n<=N_FFT_/2; n++)
            if (yDb[n] > 0)
                yDb[n] = 10.0f*log10f(yDb[n]/max);
            else
                yDb[n] = -100.0f;

        // Output to terminal
//    float dt = 1.0e3f/FS_;
        float df = FS_/N_FFT_;
//    for (int n=0; n<N_FFT_; n++)
//    {
//        if (n <= N_FFT_/2)
//            printf("%3d, %4.1f,%8.4f, %10.4f,%6.1f\r\n",
//                   n, n*dt, xn_[n], n*df, yDb[n]);
//        else
//            printf("%3d, %4.1f,%8.4f\r\n", n, n*dt, xn_[n]);
//    }

        VCC=1;
        GND=0;
        //TFT_send(4,0);
        for(int r=0; r<30; r++) {
            for(int c=0; c<400; c++) {
                screen[r][c]=0;
            }
        }
        for(int n=18; n<N_FFT_/2 && n<400; n++) {
            for(int p=(-yDb[n])*8; p<240-8; p++) {
                screen[p>>3][n]|=(1<<(p&0x7));
            }
        }
        for(int r=0; r<30; r+=2) {
            for(int line=0; line<5; line++) {
                screen[r][line]=character('-',line);
                screen[r][line+6]=character('0'+r*8/8/10,line);
                screen[r][line+12]=character('0'+r*8/8%10,line);
            }
        }
        int f=0;
        for(int n=0; n<400; n++) {
            if(f!=(int)(df*n/500)) {
                f++;
                for(uint8_t line=0; line<5; line++) {
                    screen[29][n+line-18]=character(5*f/10+'0',line);
                    screen[29][n+line-12]=character('.',line);
                    screen[29][n+line-6]=character(5*f%10+'0',line);
                    screen[29][n+line]=character('k',line);
                }
            }
        }
        printlcd();
        //wait_ms(200);
    }
}
